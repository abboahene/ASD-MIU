public interface HTMLComponent {

    String format();
}
