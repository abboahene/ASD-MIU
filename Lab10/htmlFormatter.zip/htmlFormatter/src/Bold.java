public class Bold extends HTMLTag{
    Bold() {
        super("b");
    }
}
