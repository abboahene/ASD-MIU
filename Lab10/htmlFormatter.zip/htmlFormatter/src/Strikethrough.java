public class Strikethrough extends HTMLTag{
    Strikethrough() {
        super("s");
    }
}
