public class Underline extends HTMLTag{
    Underline() {
        super("u");
    }
}
