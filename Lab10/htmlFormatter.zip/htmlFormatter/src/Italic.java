public class Italic extends HTMLTag{
    Italic() {
        super("i");
    }
}
