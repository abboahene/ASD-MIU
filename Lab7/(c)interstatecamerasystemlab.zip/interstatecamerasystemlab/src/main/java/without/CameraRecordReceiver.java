package without;



public class CameraRecordReceiver {

	
	public void receiveCameraRecord(CameraRecord cameraRecord) {
		System.out.println("receiving "+cameraRecord);
	}


}
