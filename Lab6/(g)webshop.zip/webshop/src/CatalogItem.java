public interface CatalogItem {

    void print();
}
