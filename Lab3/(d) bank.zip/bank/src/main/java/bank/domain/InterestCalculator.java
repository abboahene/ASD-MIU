package bank.domain;

public abstract class InterestCalculator {
    public abstract double calcInterest(Account account);
}
