public enum GateState {
    OPEN,
    CLOSED,
    OPENING,
    CLOSING
}
