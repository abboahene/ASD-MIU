package main.java.counter;

public interface Observer {

    void update(int cnt);
}
