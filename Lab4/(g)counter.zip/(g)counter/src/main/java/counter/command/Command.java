package main.java.counter.command;

public interface Command {
    void execute();
    void unExecute();
}
